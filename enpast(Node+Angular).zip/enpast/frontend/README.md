Enpast-web
==============================
for start:

npm install -g http-server

http-server

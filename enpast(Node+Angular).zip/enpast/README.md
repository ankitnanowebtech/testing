API Server v1:

# Check User
To check user credentials and logging in you need to call **/api/check_user** with following options:

* POST to **/api/check_user** with two parameters: **email** and **password**

* Return values:

    **return_code: 1000** - Success. Here you will also have SSID set in Cookie and this Cookie will be used for further calls as logged in user.
    
    **return_code: 1001** - Invalid username or password
    
    **return_code: 1002** - Username and password is correct, but user is not active
    
    **return_code: 1003** - Username and password is correct, but email is not verified.
    
#### Sample Call: 
*POST /api/check_user HTTP/1.1*

...

...

*{email: "admin@admin.com", "password": "admin"}*


<br><br><br><br><br><br><br><br>



# Create User
To create a user, you need to call **/api/create_user** with following options: (for now only Enterprise user account creation is supported in server. Server wont' store excess received information such as address, zipcode, etc)

* POST to **/api/create_user** with four parameters: **email**, **password**, **firstname** and **lastname**.

* Return values:

    **return_code: 1000** - Success. User is created. Not verify your email address and wait for your user to be activated (default is active, unless if enterprise admin opts to manually activated new users)
    
    **return_code: 1005** - Mandatory email, firstname, lastname or password field is missing.
    
    **return_code: 1006** - Username/email already exists
    
    

#### Sample Call: 
*POST /api/create_user HTTP/1.1*

...

...

*{"firstname": "Test", "lastname": "Tester", "email": "admin@admin.com", "password": "admin"}*


<br><br><br><br><br><br><br><br>


# Create Container
To create a container, you need to call **/api/create_container** with following options:

* POST to **/api/create_container** with two mandatory and four optional parameters: Mandatory: **container_name**, **encryption_type** Optional: **encrypted_random**, **icon_url** and **time_expires**.

* Return values:

    **return_code: 1000** - Success. container is created. 

    **return_code: 1005** - A mandatory field is missing.

    **return_code: 1008** - User is not logged in / Cookie field is missing / User timed out

    **return_code: 1009** - Container name already exists.
    


#### Sample Call: 
*POST /api/create_container HTTP/1.1*

...

...

*{"container_name": "NewContainer", "icon_info": "Base64EncodedData", "encryption_type": "C123", "encrypted_random": "Base64EncodedCryptedRandHere"}*

  
<br><br><br><br><br><br><br><br>



# Create Folder
To create a Folder, you need to call **/api/create_folder** with following options:

* POST to **/api/create_folder** with two mandatory and two optional parameters: Mandatory: **folder_name**, **pid** Optional: **pfid**, **icon_url** and **time_expires**.

* pfid => Parent Folder ID, ID of the parent folder if its being created under a folder. If it's top level folder under container, send it empty
* pid  => Parent/Top container ID

* Return values:

    **return_code: 1000** - Success. Folder is created. 

    **return_code: 1005** - A mandatory field is missing.

    **return_code: 1008** - User is not logged in / Cookie field is missing / User timed out

    **return_code: 1009** - Folder name already exists in same parent folder.
    


#### Sample Call: 
*POST /api/create_container HTTP/1.1*

...

...

*{"container_name": "NewContainer", "icon_info": "Base64EncodedData", "encryption_type": "C123", "encrypted_random": "Base64EncodedCryptedRandHere"}*

  
<br><br><br><br><br><br><br><br>

# Get Container and Folder Structure
To get the list of container and folder hierarcy, you need to call **/api/get_containerfolderlist** with no parameter, only user's cookie should be in the request header.
This API can be called with POST or GET.

* Return values:

    **return_code: 1000** - Success. Read the list object

    **return_code: 1008** - User is not logged in / Cookie field is missing / User timed out

    **return_code: 1010** - Empty dataset. User doesn't have any container or folder


#### Sample Call: 
*POST (or GET) /api/get_containerfolderlist HTTP/1.1*

...

...

<br><br><br><br><br><br><br><br>

#### Sample Response: 

[

  {

    "return_code": 1000,

    "data": [

      {

        "id": "2b1171e6-41bc-49a6-87fa-af4b44eca0f3",

        "name": "MainContainer1",

        "encryption": "A1",

        "icon_info": "",

        "created_at": "2016-11-07T01:14:35.731Z",

        "expires_at": null,

        "randcrypt": "",

        "contents": [

          {

            "id": "8b7790e9-17ab-49dd-bfb5-6f67ba9b87e2",

            "name": "MainFolder1",

            "icon_info": "",

            "created_at": "2016-11-07T01:32:49.224Z",

            "expires_at": null,

            "contents": {}

          },

          {

            "id": "49d4ae36-f812-4c3e-81b1-dd7f5f1f07fe",

            "name": "MainFolder2",

            "icon_info": "",

            "created_at": "2016-11-07T01:33:15.102Z",

            "expires_at": null,

            "contents": [

              {

                "id": "3e6b4311-4c0a-4630-bd3e-680b057a38d3",

                "name": "MainFolder2Sub1",

                "icon_info": "",

                "created_at": "2016-11-07T01:34:13.991Z",

                "expires_at": null,

                "contents": {}

              },

              {

                "id": "77807f0b-801c-4ff5-8e41-50fd0dd4021f",

                "name": "MainFolder2Sub2",

                "icon_info": "",

                "created_at": "2016-11-07T01:34:25.666Z",

                "expires_at": null,

                "contents": [

                  {

                    "id": "aabe182a-a156-4973-8905-5d824e1a8077",

                    "name": "MainFolder2Sub2Sub1",

                    "icon_info": "",

                    "created_at": "2016-11-07T03:45:39.792Z",

                    "expires_at": null,

                    "contents": {}

                  },

                  {

                    "id": "6b2c283b-cc45-4d0f-830f-13108d1f3d80",

                    "name": "MainFolder2Sub2Sub2",

                    "icon_info": "",

                    "created_at": "2016-11-07T03:45:49.899Z",

                    "expires_at": null,

                    "contents": {}

                  },

                  {

                    "id": "195019e6-748e-4215-8dbb-82ebc9398c6f",

                    "name": "MainFolder2Sub2Sub3",

                    "icon_info": "",

                    "created_at": "2016-11-07T03:45:55.185Z",

                    "expires_at": null,

                    "contents": {}

                  }

                ]

              }

            ]

          }

        ]

      },

      {

        "id": "e299668d-5105-4c74-a489-d32090136d86",

        "name": "MainContainer2",

        "encryption": "B1",

        "icon_info": "",

        "created_at": "2016-11-07T01:17:32.307Z",

        "expires_at": null,

        "randcrypt": "",

        "contents": {}

      },

      {

        "id": "8f3f749f-b38d-45c2-bc64-a609b75e729f",

        "name": "MainContainer3",

        "encryption": "B3",

        "icon_info": "",

        "created_at": "2016-11-07T01:18:48.655Z",

        "expires_at": null,

        "randcrypt": "",

        "contents": {}

      }

    ]

  }

]

(Original Response doesn't have new lines)
<<<<<<< HEAD

=======
>>>>>>> refs/remotes/origin/master
